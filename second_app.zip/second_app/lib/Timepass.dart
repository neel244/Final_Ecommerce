// import 'package:flutter/material.dart';
// import 'main.dart';

// class HomePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.pink,
//       child: Text('Hey',style: TextStyle(color : Colors.white),),
//     );
//   }
// }
// class HomePage extends StatefulWidget {
//   @override
//   _HomePageState createState() => _HomePageState();
// }

// class _HomePageState extends State<HomePage> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       child:
//       Text('Stateful')
//     );
//   }
// }

// import 'package:flutter/material.dart';

// void main()
// {
//   runApp(
//     new MaterialApp(
//       home: GridView.count(crossAxisCount : 2,
//       children: <Widget>[
//         Text ('one'),
//         Text ('two'),
//         Text ('three'),
//       ],
//       )

//     )
//   );
// }

// MAIN DART

// import 'package:flutter/material.dart';

// void main()
// {
//   runApp(
//     MaterialApp(
//       home : Container(
//         child: Column(
//           children: <Widget>[
//             // Icon(Icons.person),
//             Text('User'),
//             Text('User'),


//         ],)
//       )
//     )
//   );
// }


// import 'package:flutter/material.dart';
// import 'home.dart';
// void main(){
//   runApp(
//     MaterialApp(
//       home : HomePage()
//     )
//   );
// }